import React from 'react'

const NewArrival = () => {
  return (
    <div>NewArrival</div>
  )
}

export default NewArrival